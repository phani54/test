<?php
define("mysqlServer","localhost"); 
define("mysqlDB","mysqlDB"); 
define("mysqlUser","mysqlUser"); 
define("mysqlPass","mysqlPass");
?>